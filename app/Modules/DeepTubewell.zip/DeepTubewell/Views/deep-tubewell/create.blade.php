@extends('main_layouts.app')


@section('content')

<div class="row animated zoomIn">
  @include('errorOrSuccess')
  <div class="col-md-12">
    <div class="portlet light bordered">

      <div class="portlet-title">
          <div class="caption font-red-sunglo">
              <i class="icon-settings font-red-sunglo"></i>
              <span class="caption-subject bold uppercase">গভীর নলকূপের তথ্য</span>
          </div>
      </div>
 
      <div class="portlet-body">
        {{Form::open(['url'=>'deep-tubewell/deep-tubewell','method'=>'post','class'=>"form-horizontal",'role'=>'form', 'enctype' => 'multipart/form-data'])}}

          <div class="form-group col-md-12">
              <label for="zone_id" class="col-md-3 control-label">জোন<span style="color:red">*</span></label>
              <div class="col-md-5">
                {!! Form::select('zone_id', $zones, null, ['class' => 'form-control select2','placeholder' => 'Select Land Zone', 'style' => 'width:100%']) !!}
              </div>
          </div>

          <div class="form-group col-md-12">
              <label for="area_id" class="col-md-3 control-label">মৌজা<span style="color:red">*</span></label>
              <div class="col-md-5">
                <select name="area_id" id="area_id" class="form-control select2" style="width: 100%;">
                  <option value="">Select Land Area</option>
                  @foreach ($areas as $key => $item)
                      <option value="{{ $key }}">{{ $item }}</option>
                  @endforeach
                </select>
              </div>
              <div class="col-md-2">
                  <button data-toggle="modal" data-target="#add-land_area-modal" type="button" class="btn btn-success bnt-lg"><i class="fa fa-plus"></i> Add New</button>
              </div>
          </div>

          <div class="form-group col-md-12">
              <label for="area_id" class="col-md-3 control-label">উৎসের ধরণ<span style="color:red">*</span></label>
              <div class="col-md-5">
                <select name="source_type" id="source_type" class="form-control select2" style="width: 100%;">
                  <option value="">Select Land Area</option>
                  @foreach ($source_type as $key => $item)
                      <option value="{{ $key }}">{{ $item }}</option>
                  @endforeach
                </select>
              </div>
              <div class="col-md-2">
                  <button data-toggle="modal" data-target="#add-land_area-modal" type="button" class="btn btn-success bnt-lg"><i class="fa fa-plus"></i> Add New</button>
              </div>
          </div>
          <div class="form-group col-md-12">
              <label for="area_id" class="col-md-3 control-label">উৎস<span style="color:red">*</span></label>
              <div class="col-md-5">
                  <input type="number" class="form-control" name="source" value="5">
              </div>
          </div>

          <div class="form-group col-md-12">
              <label for="area_id" class="col-md-3 control-label">অনুমতি/চুক্তি/বরাদ্দ<span style="color:red">*</span></label>
              <div class="col-md-5">
              <input type="radio" name="onumoti_chukti_boraddo" value="1" id="onumoti">
                <label for="onumoti">অনুমতি</label>  
                <input type="radio" name="onumoti_chukti_boraddo" value="2" id="cukti">
                <label for="cukti">চুক্তি</label>
                <input type="radio" name="onumoti_chukti_boraddo" value="3" id="boraddo">
                <label for="boraddo">বরাদ্দ</label>  
              </div>
          </div>

          <div class="form-group col-md-12">
              <label for="area_id" class="col-md-3 control-label">অনুমতি/চুক্তি/বরাদ্দ তারিখ<span style="color:red">*</span></label>
              <div class="col-md-5">
                  <input type="date" class="form-control" name="onumoti_chukti_boraddo_date">
              </div>
          </div>

          <div class="form-group col-md-12" style="margin-left: 70px;">
            <label for="coordinates" class="col-md-2 control-label" style="margin-top: 5px;">অনুমতি/চুক্তি/বরাদ্দ সংযুক্তি</label>
            <div class="col-md-3" style="margin-top: 5px;">
                {{ Form::text('onumoti_chukti_boraddo_attach_name', null, ['class' => 'form-control', 'placeholder' => 'Document Name']) }}
                <!-- doc_1 -->
            </div>
            <div class="col-md-3" style="margin-top: 5px;">
                {{ Form::file('onumoti_chukti_boraddo_attach', null, ['class' => '']) }}
            </div>
          </div>

          <div class="form-group col-md-12">
              <label for="area_id" class="col-md-3 control-label">দখলপত্র তারিখ<span style="color:red">*</span></label>
              <div class="col-md-5">
                  <input type="date" class="form-control" name="dokholpotro_date">
              </div>
          </div>

          <div class="form-group col-md-12" style="margin-left: 70px;">
            <label for="coordinates" class="col-md-2 control-label" style="margin-top: 5px;">দখলপত্র সংযুক্তি</label>
            <div class="col-md-3" style="margin-top: 5px;">
                {{ Form::text('dokholpotro_attach_name', null, ['class' => 'form-control', 'placeholder' => 'Document Name']) }} 
                <!-- doc_name_2 -->
            </div>
            <div class="col-md-3" style="margin-top: 5px;">
                {{ Form::file('dokholpotro_attach', null, ['class' => '']) }}
            </div>
          </div>

          <div class="form-group col-md-12">
              <label for="area_id" class="col-md-3 control-label">স্থাপনা/গভীর নলকূপের জায়গার নাম<span style="color:red">*</span></label>
              <div class="col-md-5">
                  <input type="text" class="form-control" name="deep_tubewell_place_name">
              </div>
          </div>

          <div class="form-group col-md-12">
              <label for="area_id" class="col-md-3 control-label">খতিয়ান নং<span style="color:red">*</span></label>
              <div class="col-md-5">
                  <input type="text" class="form-control" name="khotiyan_no">
              </div>
          </div>
          <div class="form-group col-md-12">
              <label for="area_id" class="col-md-3 control-label">দাগ নং<span style="color:red">*</span></label>
              <div class="col-md-5">
                  <input type="text" class="form-control" name="dag_no">
              </div>
          </div>

          <div class="form-group col-md-12">
              <label for="area_id" class="col-md-3 control-label">জমির পরিমান (একর)<span style="color:red">*</span></label>
              <div class="col-md-5">
                  <input type="text" class="form-control" name="jomir_poriman">
              </div>
          </div>
          <div class="form-group col-md-12">
              <label for="area_id" class="col-md-3 control-label">গন্তব্য<span style="color:red">*</span></label>
              <div class="col-md-5">
                  <input type="text" class="form-control" name="destination">
              </div>
          </div>  

          <div class="form-group col-md-12">
              <label for="area_id" class="col-md-3 control-label">অন্যান্য<span style="color:red">*</span></label>
          </div>  



          
          <!-- <div class="form-group col-md-12" style="margin-left: 70px;">
            <label for="coordinates" class="col-md-2 control-label" style="margin-top: 5px;">Document Name 3</label>
            <div class="col-md-3" style="margin-top: 5px;">
                {{ Form::text('doc_name_3', null, ['class' => 'form-control', 'placeholder' => 'Document Name']) }}
            </div>
            <div class="col-md-3" style="margin-top: 5px;">
                {{ Form::file('doc_3', null, ['class' => '']) }}
            </div>
          </div>
          <div class="form-group col-md-12" style="margin-left: 70px;">
            <label for="coordinates" class="col-md-2 control-label" style="margin-top: 5px;">Document Name 4</label>
            <div class="col-md-3" style="margin-top: 5px;">
                {{ Form::text('doc_name_4', null, ['class' => 'form-control', 'placeholder' => 'Document Name']) }}
            </div>
            <div class="col-md-3" style="margin-top: 5px;">
                {{ Form::file('doc_4', null, ['class' => '']) }}
            </div>
          </div>
          <div class="form-group col-md-12" style="margin-left: 70px;">
            <label for="coordinates" class="col-md-2 control-label" style="margin-top: 5px;">Document Name 5</label>
            <div class="col-md-3" style="margin-top: 5px;">
                {{ Form::text('doc_name_5', null, ['class' => 'form-control', 'placeholder' => 'Document Name']) }}
            </div>
            <div class="col-md-3" style="margin-top: 5px;">
                {{ Form::file('doc_5', null, ['class' => '']) }}
            </div>
          </div> -->
          
          <hr>
          <div class="form-group">
              <div class="col-md-11 text-center" style="padding-bottom: 20px; margin-top: 10px;">
                  <button type="submit" class="btn blue">Submit</button>
              </div>
          </div>
          {{Form::close()}}
          <div id="map_canvas" class="col-md-12" style="height: 450px; margin: 0.6em;"></div>

      </div>

    </div>
  </div>
</div>






@endsection

@section('scripts')
<script>
  
</script>
@endsection
