@extends('main_layouts.app')

@section('content')

<div class="row animated zoomIn">
  @include('errorOrSuccess')
  <div class="col-md-12">
    <div class="portlet light bordered">
      <div class="portlet-title">
          <div class="caption font-red-sunglo">
              <i class="icon-settings font-red-sunglo"></i>
              <span class="caption-subject bold uppercase">গভীর নলকূপের তথ্য</span>
          </div>
      </div>  

      <div class="portlet-body">
        {{Form::open(['url'=>'deep-tubewell/deep-tubewell/'.$deep_tubewell->id,'method'=>'put','class'=>"form-horizontal",'role'=>'form', 'enctype' => 'multipart/form-data'])}}
          
          <div class="form-group col-md-12">
              <label for="zone_id" class="col-md-3 control-label">জোন<span style="color:red">*</span></label>
              <div class="col-md-5">
                {!! Form::select('zone_id', $zones, $deep_tubewell->zone_id, ['class' => 'form-control select2','placeholder' => 'Select Zone', 'style' => 'width:100%']) !!}
              </div>
          </div>
          <div class="form-group col-md-12">
              <label for="area_id" class="col-md-3 control-label">মৌজা<span style="color:red">*</span></label>
              <div class="col-md-5">
                {!! Form::select('area_id', $areas, $deep_tubewell->area_id, ['class' => 'form-control select2','placeholder' => 'Select Area', 'style' => 'width:100%']) !!}
              </div>
          </div>
          <div class="form-group col-md-12">
              <label for="source_id" class="col-md-3 control-label">উৎসের ধরণ<span style="color:red">*</span></label>
              <div class="col-md-5">
                {!! Form::select('source_type', $source_type, $deep_tubewell->source_type, ['class' => 'form-control select2','placeholder' => 'Select Source type', 'style' => 'width:100%']) !!}
              </div>
          </div>


          <div class="form-group col-md-12">
              <label for="area_id" class="col-md-3 control-label">উৎস<span style="color:red">*</span></label>
              <div class="col-md-5">
                  <input type="number" class="form-control" name="source" value="5">
              </div>
          </div>

          <div class="form-group col-md-12">
              <label for="area_id" class="col-md-3 control-label">অনুমতি/চুক্তি/বরাদ্দ<span style="color:red">*</span></label>
              <div class="col-md-5">
              <input type="radio" name="onumoti_chukti_boraddo" value="1" id="onumoti" <?php if($deep_tubewell->onumoti_chukti_boraddo==1){echo "checked";}?>>
                <label for="onumoti">অনুমতি</label>  
                <input type="radio" name="onumoti_chukti_boraddo" value="2" id="cukti" <?php if($deep_tubewell->onumoti_chukti_boraddo==2){echo "checked";}?>>
                <label for="cukti">চুক্তি</label>
                <input type="radio" name="onumoti_chukti_boraddo" value="3" id="boraddo" <?php if($deep_tubewell->onumoti_chukti_boraddo==3){echo "checked";}?>>
                <label for="boraddo">বরাদ্দ</label>  
              </div>
          </div>

          <div class="form-group col-md-12">
              <label for="area_id" class="col-md-3 control-label">অনুমতি/চুক্তি/বরাদ্দ তারিখ<span style="color:red">*</span></label>
              <div class="col-md-5">
                  <input type="date" class="form-control" name="onumoti_chukti_boraddo_date" value="{{$deep_tubewell->onumoti_chukti_boraddo_date}}">
              </div>
          </div>

          <div class="form-group col-md-12" style="margin-left: 70px;">
            <label for="coordinates" class="col-md-2 control-label" style="margin-top: 5px;">অনুমতি/চুক্তি/বরাদ্দ সংযুক্তি</label>
            <div class="col-md-3" style="margin-top: 5px;">
                {{ Form::text('onumoti_chukti_boraddo_attach_name', $deep_tubewell->onumoti_chukti_boraddo_attach_name, ['class' => 'form-control' , 'id' => 'title','required'=>'required']) }}
                <!-- doc_1 -->
            </div>
            <div class="col-md-3" style="margin-top: 5px;">
                {{ Form::file('onumoti_chukti_boraddo_attach', null, ['class' => '']) }}
            </div>
          </div>

          <div class="form-group col-md-12">
              <label for="area_id" class="col-md-3 control-label">দখলপত্র তারিখ<span style="color:red">*</span></label>
              <div class="col-md-5">
                  <input type="date" class="form-control" name="dokholpotro_date" value="{{$deep_tubewell->dokholpotro_date}}">
              </div>
          </div>

          <div class="form-group col-md-12" style="margin-left: 70px;">
            <label for="coordinates" class="col-md-2 control-label" style="margin-top: 5px;">দখলপত্র সংযুক্তি</label>
            <div class="col-md-3" style="margin-top: 5px;">
                {{ Form::text('dokholpotro_attach_name', $deep_tubewell->dokholpotro_attach_name, ['class' => 'form-control', 'placeholder' => 'Document Name']) }} 
                <!-- doc_name_2 -->
            </div>
            <div class="col-md-3" style="margin-top: 5px;">
                {{ Form::file('dokholpotro_attach', null, ['class' => '']) }}
            </div>
          </div>

          <div class="form-group col-md-12">
              <label for="area_id" class="col-md-3 control-label">স্থাপনা/গভীর নলকূপের জায়গার নাম<span style="color:red">*</span></label>
              <div class="col-md-5">
                  <input type="text" class="form-control" name="deep_tubewell_place_name" value="{{$deep_tubewell->deep_tubewell_place_name}}">
              </div>
          </div>

          <div class="form-group col-md-12">
              <label for="area_id" class="col-md-3 control-label">খতিয়ান নং<span style="color:red">*</span></label>
              <div class="col-md-5">
                  <input type="text" class="form-control" name="khotiyan_no" value="{{$deep_tubewell->khotiyan_no}}">
              </div>
          </div>
          <div class="form-group col-md-12">
              <label for="area_id" class="col-md-3 control-label">দাগ নং<span style="color:red">*</span></label>
              <div class="col-md-5">
                  <input type="text" class="form-control" name="dag_no" value="{{$deep_tubewell->dag_no}}">
              </div>
          </div>

          <div class="form-group col-md-12">
              <label for="area_id" class="col-md-3 control-label">জমির পরিমান (একর)<span style="color:red">*</span></label>
              <div class="col-md-5">
                  <input type="text" class="form-control" name="jomir_poriman" value="{{$deep_tubewell->jomir_poriman}}">
              </div>
          </div>
          <div class="form-group col-md-12">
              <label for="area_id" class="col-md-3 control-label">গন্তব্য<span style="color:red">*</span></label>
              <div class="col-md-5">
                  <input type="text" class="form-control" name="destination" value="{{$deep_tubewell->destination}}">
              </div>
          </div>  

          <div class="form-group col-md-12">
              <label for="area_id" class="col-md-3 control-label">অন্যান্য<span style="color:red">*</span></label>
          </div> 

          <hr>
          <div class="form-group">
              <div class="col-md-11 text-center" style="padding-bottom: 20px; margin-top: 10px;">
                  <button type="submit" class="btn blue">Submit</button>
              </div>
          </div>
          {{Form::close()}}
          <div id="map_canvas" class="col-md-12" style="height: 450px; margin: 0.6em;"></div>

      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
  $(document).ready(function () {

    $('#nopagination').DataTable({
      "paging": true,
      "bFilter": true,
      "info": true
    });

    highlight_nav('land');
  });
</script>


@endsection

@section('scripts')
<script>
 
</script>
@endsection
