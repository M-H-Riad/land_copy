-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2023 at 06:20 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wasa_new_live`
--

-- --------------------------------------------------------

--
-- Table structure for table `deep_tubewell`
--

CREATE TABLE `deep_tubewell` (
  `id` int(11) NOT NULL,
  `zone_id` int(11) NOT NULL,
  `area_id` int(11) NOT NULL,
  `source_type` int(11) NOT NULL,
  `source` int(11) NOT NULL,
  `onumoti_chukti_boraddo` tinyint(3) NOT NULL,
  `onumoti_chukti_boraddo_date` varchar(50) NOT NULL,
  `onumoti_chukti_boraddo_attach_name` varchar(255) NOT NULL,
  `onumoti_chukti_boraddo_attach` varchar(255) NOT NULL,
  `dokholpotro_date` varchar(50) NOT NULL,
  `dokholpotro_attach_name` varchar(255) NOT NULL,
  `dokholpotro_attach` varchar(255) NOT NULL,
  `deep_tubewell_place_name` varchar(255) NOT NULL,
  `khotiyan_no` varchar(255) NOT NULL,
  `dag_no` varchar(255) NOT NULL,
  `jomir_poriman` varchar(255) NOT NULL,
  `destination` varchar(255) NOT NULL,
  `other_attach` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deep_tubewell`
--

INSERT INTO `deep_tubewell` (`id`, `zone_id`, `area_id`, `source_type`, `source`, `onumoti_chukti_boraddo`, `onumoti_chukti_boraddo_date`, `onumoti_chukti_boraddo_attach_name`, `onumoti_chukti_boraddo_attach`, `dokholpotro_date`, `dokholpotro_attach_name`, `dokholpotro_attach`, `deep_tubewell_place_name`, `khotiyan_no`, `dag_no`, `jomir_poriman`, `destination`, `other_attach`, `created_at`, `updated_at`) VALUES
(5, 10, 267, 2, 15, 2, '2023-04-15', 'boraddo', 'uploads/deep-tubewell/-11681312884.png', '2023-04-22', 'dokholpotro2', 'uploads/deep-tubewell/-21681312884.png', 'Rampura', 'aa1', 'bb2', '5 ekor', 'Motijheel', '', '2023-04-12 15:21:24', '2023-04-12 15:21:24'),
(6, 10, 267, 2, 23, 3, '2023-04-24', 'boraddo3', '', '2023-04-18', 'dokholpotro3', 'uploads/deep-tubewell/-21681313072.png', 'Malibag', 'cc1', 'dd1', '12 ekor', 'Banasree', '', '2023-04-12 15:24:32', '2023-04-12 15:24:32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `deep_tubewell`
--
ALTER TABLE `deep_tubewell`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `deep_tubewell`
--
ALTER TABLE `deep_tubewell`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
